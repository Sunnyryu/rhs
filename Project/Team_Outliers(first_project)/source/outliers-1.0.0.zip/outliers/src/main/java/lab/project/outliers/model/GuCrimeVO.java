package lab.project.outliers.model;

public class GuCrimeVO {
	private int year;
	private String gu;
	private int total;
	private int murder;
	private int robber;
	private int sexual_assault;
	private int theft;
	private int violence;
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public String getGu() {
		return gu;
	}
	public void setGu(String gu) {
		this.gu = gu;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public int getMurder() {
		return murder;
	}
	public void setMurder(int murder) {
		this.murder = murder;
	}
	public int getRobber() {
		return robber;
	}
	public void setRobber(int robber) {
		this.robber = robber;
	}
	public int getSexual_assault() {
		return sexual_assault;
	}
	public void setSexual_assault(int sexual_assault) {
		this.sexual_assault = sexual_assault;
	}
	public int getTheft() {
		return theft;
	}
	public void setTheft(int theft) {
		this.theft = theft;
	}
	public int getViolence() {
		return violence;
	}
	public void setViolence(int violence) {
		this.violence = violence;
	}
	
	
	
	
	
}
