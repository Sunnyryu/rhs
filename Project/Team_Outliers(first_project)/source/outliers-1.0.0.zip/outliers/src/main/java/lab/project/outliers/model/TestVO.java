package lab.project.outliers.model;

public class TestVO {
	private String cctv_id;

	public String getCctv_id() {
		return cctv_id;
	}

	public void setCctv_id(String cctv_id) {
		this.cctv_id = cctv_id;
	}
	
}
